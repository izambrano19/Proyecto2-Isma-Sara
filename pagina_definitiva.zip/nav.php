
<body>
    <style>
        .icono-cerrarsesion{
            width: 30px;
            display: flex;
        }
        </style>
    <header>
        <div class="container_menu">
            <div class="logo">
                <a href="index.php"><img src="img/logo.png" alt="logo"></a>
            </div>

            <div class="menu">
                <i class="fas fa-bars" id="btn_menu"></i>
                <div id="back_menu"></div>
                <nav id="nav">
                    <div id="logo2">
                        <a href="index.php"><img src="img/logo.png" alt="logo"></a>
                    </div>
                    <ul id="menu-nav">
                        <li><a href='index.php' id='selected'>HOMEPAGE</a></li>
                        <li><a href="statistics.php">STATISTICS</a></li>
                        <li><a href="proteinas.php">PROTEINAS</a></li>
                        <li><a href="farmacos.php">FÁRMACOS</a></li>
                        <li><a href="administracion/login.php">LOGIN</a></li>
                    </ul>

                </nav>

            </div>

        </div>
    </header>

    <script src="js/script.js"></script>