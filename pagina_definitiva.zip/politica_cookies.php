<?php require("header.php")?>
<title>POLITICA DE COOKIES</title>
</head>
<?php require("nav.php")?>

    <div style="margin-top: 100px">
    </div>
    <div class="container_grande">
        <h1>¿Qué son las cookies?</h1>
        <hr class="line">

        <p>Una cookie es un pequeño archivo de texto que un sitio web guarda en su computadora o dispositivo móvil cuando visita el sitio. Permite que el sitio web recuerde sus acciones y preferencias (como inicio de sesión, idioma, tamaño de fuente y otras preferencias de visualización) durante un período de tiempo, para que no tenga que volver a ingresarlas cada vez que regrese al sitio o navegar de una página a otra.</p>

        <p>Las cookies son esenciales para el correcto funcionamiento de internet, aportando numerosas ventajas para mejorar los servicios interactivos, facilitándote la navegación por la web. Las cookies no dañan el hardware sino que nos ayudan a identificar y solucionar errores.</p>

        <h1>Relación y descripción de las cookies que utilizamos en la página web</h1>
        <hr class="line">

        <div class="container_tabla_cookies">
            <table>
                <thead>
                    <tr>
                        <th scope="col"><b>Nombre</b></th>
                        <th scope="col"><b>Propósito</b></th>
                        <th scope="col"><b>Descripción</b></th>
                        <th scope="col"><b>Proveedor</b></th>
                        <th scope="col"><b>Duración</b></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>PHPSESSID</td>
                        <td>Necesaria</td>
                        <td>Esta cookie se utiliza para guardar los datos de la sesión del usuario. Es esencial para el funcionamiento de la web.</td>
                        <td>Propia</td>
                        <td>Sesión</td>
                    </tr>

                    <tr>
                        <td>pd_cc</td>
                        <td>Necesaria</td>
                        <td>Esta cookie identifica si el usuario ha aceptado o no el uso de cookies.</td>
                        <td>Propia</td>
                        <td>Sesión</td>
                    </tr>

                    <tr>
                        <td>_ga<br>
                            _ga_N81JXPNBT3</td>
                        <td>Análisis</td>
                        <td>Esta cookie es instalada por Google Analytics. La cookie se utiliza para calcular los datos de visitantes, sesiones y campañas y realizar un seguimiento del uso del sitio para el informe de análisis del sitio. Las cookies almacenan información de forma anónima y asignan un número generado aleatoriamente para identificar visitantes únicos.</td>
                        <td><a href="http://www.google.com/intl/es/policies/privacy/" target="_blank" class="external" rel="external">Google Analytics</a></td>
                        <td>2 años</td>
                    </tr>
                    <tr>
                        <td>_gid</td>
                        <td>Análisis</td>
                        <td>Esta cookie es instalada por Google Analytics. La cookie se utiliza para almacenar información sobre cómo los visitantes usan un sitio web y ayuda a crear un informe analítico de cómo está funcionando el sitio web. Los datos recogidos incluyendo el número de visitantes, la fuente de procedencia y las páginas visitadas de forma anónima.</td>
                        <td><a href="http://www.google.com/intl/es/policies/privacy/" target="_blank" class="external" rel="external">Google Analytics</a></td>
                        <td>1 día</td>
                    </tr>

                </tbody>
            </table>

        </div>
        
        <p>
            Para entender mejor los diferentes tipos de cookies, le facilitamos una definición de los diversos tipos de cookies que existen:






        </p>

        <ul>
            <li><b>Cookies necesarias:</b> son aquellas que existen sólo mientras el usuario navega por la web y que desaparecen cuando el usuario abandona la página web. Sirven para mantener información básica sobre la navegación y así poder ofrecer una mejor experiencia al usuario.</li>
            <li><b>Cookies de personalización:</b> se mantienen entre visitas al mismo web y sirven para guardar las personalizaciones del usuario, tales como el idioma en que ha navegado.</li>
            <li><b>Cookies analíticas:</b> almacenan para poder elaborar estadísticas sobre el tráfico y volumen de visitas de esta web.</li>
            <li><b>Cookies publicitarias:</b> muestran publicidad en función de su navegación, su país de procedencia, idioma y otros factores.</li>
            <li><b>Redes sociales:</b> a veces en algunos apartados de la página web se puede compartir el contenido en las redes sociales y éstas pueden utilizar sus propias cookies.</li>
        </ul>

        <h2>Otras cookies de terceros</h2>

        <p>Algunas de nuestras páginas pueden mostrar contenido de proveedores externos, p. YouTube, Facebook y Twitter.
             Para ver este contenido de terceros, primero debe aceptar sus términos y condiciones específicos. Esto incluye sus políticas de cookies, sobre las que no tenemos control.<br>Pero si no ve este contenido, no se instalarán cookies de terceros en su dispositivo.</p>

        <p><b>Terceros proveedores que este sitio web puede tener:</b></p>
        
        <div class="links_cookies">
            <ul>
                <li><a href="https://www.youtube.com/t/terms">You Tube</a></li>
                <li><a href="https://www.google.com/intl/en_be/help/terms_maps/">Google Maps</a></li>
                <li><a href="https://twitter.com/en/tos?wcmmode=disabled#intlTerms">Twitter</a></li>
                <li><a href="https://vimeo.com/terms">Vimeo</a></li>
                <li><a href="https://www.microsoft.com/en/servicesagreement/">Microsoft</a></li>
                <li><a href="https://www.facebook.com/legal/terms">Facebook</a></li>
                <li><a href="https://policies.google.com/terms?hl=en&gl=be">Google</a></li>
                <li><a href="https://www.linkedin.com/legal/user-agreement">LinkedIn</a></li>
    
            </ul>
        </div>

        <p>Estos servicios de terceros están fuera del control de la Comisión. Los proveedores pueden, en cualquier momento, cambiar sus términos de servicio, propósito y uso de cookies, etc.</p>

        <h1>Cómo controlar las cookies</h1>
        <hr class="line">

        <p>Puede controlar y/o eliminar las cookies como desee. Puede eliminar todas las cookies que ya están en su computadora y puede configurar la mayoría de los navegadores para evitar que se coloquen. Sin embargo, si hace esto, es posible que deba ajustar manualmente algunas preferencias cada vez que visite un sitio y es posible que algunos servicios y funcionalidades no funcionen.</p>

        <p>La siguiente es una lista de los navegadores más comunes:</p>

        <p><b>Internet Explorer</b><br>
            <a href="https://support.microsoft.com/en-us/help/17442/windows-internet-explorer-delete-manage-cookies">https://support.microsoft.com/en-us/help/17442/windows-internet-explorer-delete-manage-cookies</a>
        </p>
        <p><b>Safari</b><br>
            <a href="https://support.apple.com/guide/safari/manage-cookies-and-website-data-sfri11471/mac">https://support.apple.com/guide/safari/manage-cookies-and-website-data-sfri11471/mac</a>
        </p>

        <p><b>Opera</b><br>
            <a href="https://help.opera.com/en/latest/web-preferences/">https://help.opera.com/en/latest/web-preferences/</a>
        </p>
        <p><b>Firefox</b><br>
            <a href="https://support.mozilla.org/en-US/kb/enable-and-disable-cookies-website-preferences">https://support.mozilla.org/en-US/kb/enable-and-disable-cookies-website-preferences</a>
        </p>
        <p><b>Google Chrome</b><br>
            <a href="https://support.google.com/chrome/answer/95647?hl=en">https://support.google.com/chrome/answer/95647?hl=en</a>
        </p>
        <p><b>Puede cambiar su consentimiento en cualquier momento desde la Configuración de cookies en nuestro sitio web.</b><br>
        <a href="#" class="pdcc-open-modal">Cambiar configuración de cookies</a>

        </p>
 
        <p><b>Update: Marzo 2023</b></p>
    </div>
    <?php require("footer.php")?>

