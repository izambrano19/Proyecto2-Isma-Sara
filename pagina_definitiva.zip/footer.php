<footer class="pie-pagina">

<div class="grupo-1">

    <div class="box">
        <figure>
            <a href="#">
                <img src="img/logo.png" alt="Logo NAIS">
            </a>
        </figure>
    </div>

    <div class="box">
        <h2>INFORMACIÓN DE CONTACTO</h2>
        <p>UBICACIÓN: C/XXX XX XXXX</p>
        <p>TELÉFONO: XXX XX XX XX</p>
        <p>CORREO: XXXXXXX@XXXXXX</p>
    </div>

    <div class="box">
        <h2>NORMATIVA LEGAL</h2>
        <p><a href="proteccion_datos.php">PROTECCIÓN DE DATOS</a></p>
        <p><a href="politica_cookies.php">POLÍTICA DE COOKIES</a></p>
        <p><a href="proteccion_datos.php">AVISO LEGAL</a></p>
        <p><a href="#" class="pdcc-open-modal">PANEL DE COOKIES</a></p>
    </div>
</div>

<div class="grupo-2">
    <small>&copy; 2022 <b>Z.MedProteins</b> - Todos los Derechos Reservados.</small>
</div>

</footer>


</body>

</html>
