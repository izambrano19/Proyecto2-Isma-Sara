<?php require("header.php")?>
<title>Z.MedProteins</title>
</head>
<?php require("nav.php")?>
    <main>
        <div class="container__cover">
            <div class="container_parrafo">
            <!--
            <p>AL LADO DE LA CIENCIA</p>
            <p>DE LA MANO DE GRANDES</p>
            <p>CIENTÍFICOS</p>
                        -->
        </div>
        </div>
    </main>
    <div class="tituloNoticias">
        <h2>NOTICIAS</h2>
    </div>
    <div class="containerComunes1">

        
        
        <div class="containerprimero">
            <img src="img/noticias/biomedicina1.jpg" alt="Imagen-1">
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris viverra id lacus id aliquam. Nunc enim massa, cursus dignissim diam a, pharetra dictum augue. Mauris non lacus rhoncus, bibendum odio ultrices, sodales diam. In ornare, metus eu suscipit venenatis, ligula tellus euismod dui, auctor iaculis dolor ante vitae tortor. Fusce pellentesque ac arcu vitae bibendum. Aliquam nec ex vitae erat vehicula facilisis. Proin dapibus nisi ut nulla tempor pretium. Aliquam eu magna eget metus commodo eleifend sed at enim. Morbi ornare posuere purus</p>

        </div>
        <div class="containersegundo">
        <img src="img/noticias/biomedicina2.jpg" alt="Imagen-2">
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris viverra id lacus id aliquam. Nunc enim massa, cursus dignissim diam a, pharetra dictum augue. Mauris non lacus rhoncus, bibendum odio ultrices, sodales diam. In ornare, metus eu suscipit venenatis, ligula tellus euismod dui, auctor iaculis dolor ante vitae tortor. Fusce pellentesque ac arcu vitae bibendum. Aliquam nec ex vitae erat vehicula facilisis. Proin dapibus nisi ut nulla tempor pretium. Aliquam eu magna eget metus commodo eleifend sed at enim. Morbi ornare posuere purus</p>

        </div>

    </div>
    

    <div class="tituloNoticias">
        <h2>LABORATORIO</h2>
    </div>
    <div class="containerComunes1" style="background-color: #CBEDD5;">

        
        
    <div class="containerprimero">
        <img src="img/noticias2/c3.jpeg" alt="Imagen-1">
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris viverra id lacus id aliquam. Nunc enim massa, cursus dignissim diam a, pharetra dictum augue. Mauris non lacus rhoncus, bibendum odio ultrices, sodales diam. In ornare, metus eu suscipit venenatis, ligula tellus euismod dui, auctor iaculis dolor ante vitae tortor. Fusce pellentesque ac arcu vitae bibendum. Aliquam nec ex vitae erat vehicula facilisis. Proin dapibus nisi ut nulla tempor pretium. Aliquam eu magna eget metus commodo eleifend sed at enim. Morbi ornare posuere purus</p>

    </div>
    <div class="containersegundo">
        <img src="img/noticias2/c2.jpg" alt="Imagen-2">
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris viverra id lacus id aliquam. Nunc enim massa, cursus dignissim diam a, pharetra dictum augue. Mauris non lacus rhoncus, bibendum odio ultrices, sodales diam. In ornare, metus eu suscipit venenatis, ligula tellus euismod dui, auctor iaculis dolor ante vitae tortor. Fusce pellentesque ac arcu vitae bibendum. Aliquam nec ex vitae erat vehicula facilisis. Proin dapibus nisi ut nulla tempor pretium. Aliquam eu magna eget metus commodo eleifend sed at enim. Morbi ornare posuere purus</p>

    </div>

</div>



    <div class="containerComunes2">

        <h2>NOTICIAS</h2>

        <div class="container2">
            <img src="img/noticias/biomedicina1.jpg" alt="Noticias">
            <img src="img/noticias/biomedicina2.jpg" alt="Noticias">

        </div>

        <div class="containerp">
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris viverra id lacus id aliquam. Nunc enim massa, cursus dignissim diam a, pharetra dictum augue. Mauris non lacus rhoncus, bibendum odio ultrices, sodales diam. In ornare, metus eu suscipit venenatis, ligula tellus euismod dui, auctor iaculis dolor ante vitae tortor. Fusce pellentesque ac arcu vitae bibendum. Aliquam nec ex vitae erat vehicula facilisis. Proin dapibus nisi ut nulla tempor pretium. Aliquam eu magna eget metus commodo eleifend sed at enim. Morbi ornare posuere purus</p>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris viverra id lacus id aliquam. Nunc enim massa, cursus dignissim diam a, pharetra dictum augue. Mauris non lacus rhoncus, bibendum odio ultrices, sodales diam. In ornare, metus eu suscipit venenatis, ligula tellus euismod dui, auctor iaculis dolor ante vitae tortor. Fusce pellentesque ac arcu vitae bibendum. Aliquam nec ex vitae erat vehicula facilisis. Proin dapibus nisi ut nulla tempor pretium. Aliquam eu magna eget metus commodo eleifend sed at enim. Morbi ornare posuere purus</p>

        </div>
    </div>

    <?php require("footer.php")?>
