<?php require("header.php")?>
<title>PROTECCION DE DATOS</title>
</head>
<?php require("nav.php")?>

    <div style="margin-top: 100px">
    </div>
    <div class="container_grande">
        <h1>¿QUIÉN ES EL RESPONSABLE DEL TRATAMIENTO DE SUS DATOS PERSONALES?
</h1>
        <hr class="line">

                <ul>
            <li><b>Responsable del Tratamiento: </b>Z.MedProteins</li>
            <li><b>Dirección: </b>Calle de la Artesanía, 55, 08042 Barcelona</li>
            <li><b>Correo electrónico: </b>proyectosaraisma@gmail.com</li>
            <li><b>Teléfono: </b>999 999 999</li>
            <li><b>Contacto del Delegado de Protección de Datos: </b>proyectosaraisma@gmail.com</li>
        </ul>
        
                <h2>¿CON QUÉ FINALIDAD TRATAMOS SUS DATOS PERSONALES?</h2>


        <p>Los datos proporcionados en los formularios de contacto se utilizarán única y exclusivamente para atender las consultas del Usuario y mantenerle informado sobre la actualidad y los servicios de Z.MedProteins, en caso de autorización expresa para esta última finalidad . Es posible que en nuestra página web existan formularios en los que se recojan sus datos para fines concretos. En estas circunstancias se estará a las condiciones específicas aplicables en cada caso.</p>

                <h2>¿ES OBLIGATORIO PROPORCIONAR TODA LA INFORMACIÓN SOLICITADA EN LOS FORMULARIOS DE LA PÁGINA WEB?</h2>


        <p>En relación con los formularios de la página web, el Usuario debe rellenar los espacios marcados como “obligatorios”. No completar los datos personales requeridos o hacerlo parcialmente puede suponer que Z.MedProteins no pueda atender sus solicitudes y, en consecuencia, Z.MedProteins quedará exonerada de toda responsabilidad por la no prestación o prestación incompleta de los servicios. licidades. Los datos personales que el Usuario facilita a Z.MedProteins deben ser actuales para que la información de los registros esté actualizada y sin errores. El Usuario responderá de la veracidad de los datos facilitados.</p>

        <h2>¿CUÁNTO TIEMPO CONSERVAREMOS SUS DATOS PERSONALES?</h2>
        <p>Los datos personales se conservarán mientras dure la finalidad por la que fueron prestados y no se solicite su supresión o revocación.</p>

        <h2>¿CUÁL ES LA LEGITIMACIÓN PARA EL TRATAMIENTO DE SUS DATOS PERSONALES?</h2>
        
        <p>La base legal para el tratamiento de sus datos es el consentimiento prestado mediante la aceptación de la cláusula de tratamiento de datos.</p>
        
                <h2>¿A QUÉ DESTINATARIOS SE COMUNICARÁN SUS DATOS?</h2>
        
        <p>No se cederán datos a terceros, salvo obligación legal. De tener intención de hacerlo se recavaría primero la autorización de las personas afectadas.</p>        
        <h2>¿CUÁLES SON SUS DERECHOS EN RELACIÓN A SUS DATOS PERSONALES?</h2>
        
        <p>El usuario puede ejercer el derecho de acceso a sus datos personales, así como solicitar la rectificación de los datos inexactos o, en su caso, solicitar su supresión cuando los datos ya no sean necesarios para los fines que fueron recogidas. También podrá solicitar la limitación, portabilidad y oposición del tratamiento de sus datos, en determinadas circunstancias y por motivos relacionados con su particular situación. Igualmente, tiene derecho a revocar su consentimiento en cualquier momento sin que ello afecte de forma retroactiva al tratamiento de datos personales realizado hasta el momento. El Usuario podrá ejercitar sus derechos referidos anteriormente, en los términos y condiciones previstas en la legislación vigente, en el domicilio social de Z.MedProteins o solicitarlo mediante el envío de un correo electrónico a  proyectosaraisma@gmail.com

En el supuesto de que no obtenga una respuesta satisfactoria y desee formular una reclamación u obtener más información al respecto de cualquiera de estos derechos, puede acudir a la Agencia Española de Protección de Datos (www.agpd.es – C/ Jorge Juan, 6 de Madrid).</p>
        
        
                        <h2>¿QUÉ MEDIDAS DE SEGURIDAD TIENE IMPLANTADAS LA ENTIDAD?</h2>
        
        <p>Z.MedProteins informa que tiene implantadas las medidas de seguridad de índole técnica y organizativas necesarias que garantizan la seguridad de los datos de carácter personal del Usuario y evitan su alteración, pérdida, tratamiento y/o acceso no autorizado de acuerdo con el estado de la tecnología, la naturaleza de los datos almacenados y los riesgos a los que están expuestos, provengan de la acción humana o del medio físico o natural, de conformidad con lo previsto en la normativa vigente.</p>      
        
 
        <p><b>Update: Marzo 2023</b></p>
    </div>
    <?php require("footer.php")?>

