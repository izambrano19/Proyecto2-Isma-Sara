const username = document.getElementById('username')
const password = document.getElementById('password')
const button = document.getElementById('button')