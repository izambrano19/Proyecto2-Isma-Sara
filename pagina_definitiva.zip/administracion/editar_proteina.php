<?php 

include_once('connexiosaraismabbdd.php');

if(!empty($_POST)){
    $alert="";
    if(empty($_POST["nombre"]) || empty($_POST["codigoApp"]) || empty($_POST["nombreFichero"]) || 
    empty($_POST["tipoFichero"]) || empty($_POST["especie"]) || empty($_POST["metodo"]) || empty($_POST["resolucion"])){
        $alert="<p class='msg_error'>Todos los campos son obligatorios</p>";
    }else{
        $ID = $_POST["ID"];
        $IDProteina = $_POST["IDProteina"];
        $nombre = $_POST["nombre"];
        $codigoApp = $_POST["codigoApp"];
        $fecha = $_POST["fecha"];
        $nombreFichero = $_POST["nombreFichero"];
        $tipoFichero = $_POST["tipoFichero"];
        $especie = $_POST["especie"];
        $metodo = $_POST["metodo"];
        $resolucion = $_POST["resolucion"];
        $DNICreador = $_POST['DNICreador'];

        $query = mysqli_query($conexion,"SELECT * FROM tproteinas WHERE IDProteina = '$ID'

        ");
        $resultado = mysqli_fetch_assoc($query);

        if($resultado > 0){
            $alert="<p class='msg_error'>La proteína ya existe</p>";
        }else{
            if(empty($_POST['fecha'])){
                $sql_update = mysqli_query($conexion, "UPDATE tproteinas
                SET Nombre = '$nombre', codigoApp = '$codigoApp', nombreFichero = '$nombreFichero', tipoFichero = '$tipoFichero', especie = '$especie', metodo = '$metodo', resolucion = '$resolucion'
                WHERE IDProteina = '$IDProteina'");
            }else{
                $sql_update = mysqli_query($conexion, "UPDATE tproteinas
                SET Nombre = '$nombre', codigoApp = '$codigoApp', fecha = '$fecha', nombreFichero = '$nombreFichero', tipoFichero = '$tipoFichero', especie = '$especie', metodo = '$metodo', resolucion = '$resolucion'
                WHERE IDProteina = '$IDProteina'");
            }
            if($sql_update){
                $alert="<p class='msg_correcto'>La proteína ha sido actualizado correctamente</p>";
            }else{
                $alert="<p class='msg_error'>Error al actualizar la proteína</p>";
            }
        }
    }
}

/* Mostrar datos */
if(empty($_GET['id_proteina'])){
    header("location: listado_proteinas.php");
}
/* aqui revisarrrrrrrrrrrrrrr */
    $ID = $_GET['id_proteina'];
    $IDProteina = $_GET['id_proteina'];

$sql = mysqli_query($conexion,"SELECT * FROM tproteinas WHERE IDProteina = '$ID'");

$resultado_sql = mysqli_num_rows($sql);

if($resultado_sql == 0){
    header("location: listado_proteinas.php");
}else{
    $option = '';
    while($row = mysqli_fetch_assoc($sql)){
        $nombre = $row['Nombre'];
        $codigoApp = $row['CodigoApp'];
        $fecha = $row['Fecha'];
        $nombreFichero = $row['NombreFichero'];
        $tipoFichero = $row['TipoFichero'];
        $especie = $row['Especie'];
        $metodo = $row['Metodo'];
        $resolucion = $row['Resolucion'];
        $DNICreador = $row['DNICreador'];
 
    }

}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <?php include_once("scripts.php")?>
    <script src="js/validate_protein.js"></script>
    <link rel="stylesheet" href="css/validate.css">
</head>
<body>
    <?php 
    
    include_once("header.php");
    

    ?>
    
<br>
<br>
<br>



<div class="container_registrar">


<h1>ACTUALIZAR PROTEINA</h1>
<hr>
<div class="alert"> <?php echo isset($alert) ? $alert : ''; ?> </div>

<form action="" id="validate" method="post">
    <input type="hidden" name="IDProteina" value="<?php echo $IDProteina; ?>">

    <label for="id">ID PROTEINA: <?php echo $IDProteina;?></label>

    <label for="nombre">Nombre</label>
    <input type="text" name="nombre" id="nombre" placeholder="Nombre" value="<?php echo $nombre;?>">

    <label for="codigoApp">codigoApp</label>
    <input type="text" name="codigoApp" id="codigoApp" placeholder="CodigoApp" minlength="9" maxlength="9" value="<?php echo $codigoApp;?>">

    <label for="fecha">fecha</label>
    <input type="date" name="fecha" id="fecha" value="<?php echo $fecha;?>">

    <label for="nombreFichero">nombreFichero</label>
    <input type="text" name="nombreFichero" id="nombreFichero" value="<?php echo $nombreFichero;?>">

    <label for="tipoFichero">tipoFichero</label>
    <input type="text" name="tipoFichero" id="tipoFichero" value="<?php echo $tipoFichero;?>">

    <label for="especie">especie</label>
    <input type="text" name="especie" id="especie" value="<?php echo $especie;?>">

    <label for="metodo">metodo</label>
    <input type="text" name="metodo" id="metodo" value="<?php echo $metodo;?>">

    <label for="resolucion">resolucion</label>
    <input type="text" name="resolucion" id="resolucion" value="<?php echo $resolucion;?>">

    <label for="dni">DNI CREADOR: <?php echo $DNICreador;?></label>

    <input class="btn_guardar" type="submit" value="Actualizar proteína">


</form>

</div>

</body>
</html>