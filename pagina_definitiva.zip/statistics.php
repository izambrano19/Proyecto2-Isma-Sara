<?php require("header.php")?>
<title>ESTADÍSTICAS</title>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript" src="js/graficos.js"></script>
    <script type="text/javascript" src="js/graficos2.js"></script>
</head>
<?php require("nav.php")?>

 

    <div class="titulo_drugs">

    <div style="margin-top: 100px">
        <h2 style="text-align: center">ESTADÍSTICAS</h2>
    </div>    </div>
    <br>
    <div class="board">
        <div class="titulo_grafica">
            <h3 class="t_grafica">PERCENTAGE OF THE POPULATION THAT USED SELF-MEDICATION IN CERTAIN SITUATIONS IN SPAIN IN 2018</h3>
        </div>
        
        <div class="sub_board">
            <div class="sep_board"></div>
            <div class="cont_board">
                <div class="graf_board">
                    <div class="barra">
                        <div class="sub_barra b1">
                        </div>
                    </div>
                    <div class="barra2">
                        <div class="sub_barra2 b2">
                        </div>
                    </div>
                    <div class="barra">
                        <div class="sub_barra b3">
                        </div>
                    </div>
                    <div class="barra2">
                        <div class="sub_barra2 b4">
                        </div>
                    </div>
                    <div class="barra">
                        <div class="sub_barra b5">
                        </div>
                    </div>
                    <div class="barra2">
                        <div class="sub_barra2 b6">
                        </div>
                    </div>
                    <div class="barra">
                        <div class="sub_barra b7">
                        </div>
                    </div>
                    <div class="barra2">
                        <div class="sub_barra2 b8">
                        </div>
                    </div>
                    <div class="barra">
                        <div class="sub_barra b9">
                        </div>
                    </div>
                    <div class="barra2">
                        <div class="sub_barra2 b10">
                        </div>
                    </div>
                </div>
                <div class="tag_board">
                    <div class="sub_tag_board">
                        <div>100%</div>
                        <div>90%</div>
                        <div>80%</div>
                        <div>70%</div>
                        <div>60%</div>
                        <div>50%</div>
                        <div>40%</div>
                        <div>30%</div>
                        <div>20%</div>
                        <div>10%</div>
                        <div>0%</div>
                    </div>
                </div>
           </div> 
            <div class="sep_board"></div>
       </div>    
    </div>

 
    <div class="wrapper"> 
        <div id="jscolumnas" style="height: 300px"></div>
        
        </div>
       
       
    </div>

    <div class="wrapper">

        <div id="jscolumnas2" style="height: 300px"></div>
    </div>


<?php require("footer.php")?>
